import pygame
from constants import TAILLE_CELLULE
from assets import load_assets

images = load_assets()

class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.direction = "down"
        self.temps_derniere_bombe = 0
        self.duree_entre_bombes = 4000

    def deplacer(self, map, bombes):
        touches = pygame.key.get_pressed()
        next_x, next_y = self.x, self.y

        if touches[pygame.K_LEFT]:
            next_x -= TAILLE_CELLULE
            self.direction = "left"
        elif touches[pygame.K_RIGHT]:
            next_x += TAILLE_CELLULE
            self.direction = "right"
        elif touches[pygame.K_UP]:
            next_y -= TAILLE_CELLULE
            self.direction = "up"
        elif touches[pygame.K_DOWN]:
            next_y += TAILLE_CELLULE
            self.direction = "down"

        next_case = map[int(next_y / TAILLE_CELLULE)][int(next_x / TAILLE_CELLULE)]
        if next_case not in [1, 2] and not any(bombe == (next_x, next_y) for bombe in bombes):
            self.x, self.y = next_x, next_y

    def afficher(self, fenetre, marge_x, marge_y):
        x, y = self.x + marge_x, self.y + marge_y
        if self.direction == "down":
            fenetre.blit(images['player_down'], (x, y))
        elif self.direction == "up":
            fenetre.blit(images['player_up'], (x, y))
        elif self.direction == "left":
            fenetre.blit(images['player_left'], (x, y))
        elif self.direction == "right":
            fenetre.blit(images['player_right'], (x, y))
