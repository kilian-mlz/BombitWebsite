import pygame
import sys
from map import charger_map, afficher_map, generer_position_ennemi
from assets import load_assets
from player import Player
from enemy import Enemy
from bomb import Bombe
from constants import *
from game_over import game_over_screen, congratulations_screen

pygame.init()

fenetre = pygame.display.set_mode((LARGEUR_FENETRE, HAUTEUR_FENETRE), pygame.FULLSCREEN)
pygame.display.set_caption("Map Bomberman")

TEMPS_POSITION = ((LARGEUR_FENETRE - 200) // 2, HAUTEUR_FENETRE - 40)
TEMPS_RESTANT_BOMBE_POSITION = ((LARGEUR_FENETRE - 300) // 2, HAUTEUR_FENETRE - 80)

def afficher_temps(fenetre, temps_ecoule):
    font = pygame.font.SysFont(None, 36)
    minutes = temps_ecoule // 60000
    seconds = (temps_ecoule % 60000) // 1000
    time_text = f'Temps: {minutes:02}:{seconds:02}'
    timer_surface = font.render(time_text, True, (255, 255, 255))
    fenetre.blit(timer_surface, TEMPS_POSITION)

def afficher_temps_restant_bombe(fenetre, temps_restant):
    font = pygame.font.SysFont(None, 36)
    time_text = f'Temps avant bombe: {temps_restant // 1000}s'
    timer_surface = font.render(time_text, True, (255, 255, 255))
    fenetre.blit(timer_surface, TEMPS_RESTANT_BOMBE_POSITION)

def main():
    clock = pygame.time.Clock()
    map = charger_map()
    joueur = Player(1 * TAILLE_CELLULE, 1 * TAILLE_CELLULE)
    game_over = False
    game_won = False

    bombes = []
    temps_bombes = {}
    temps_debut_partie = pygame.time.get_ticks()

    largeur_carte = len(map[0]) * TAILLE_CELLULE
    hauteur_carte = len(map) * TAILLE_CELLULE
    marge_x = (LARGEUR_FENETRE - largeur_carte) // 2
    marge_y = (HAUTEUR_FENETRE - hauteur_carte) // 2

    enemies = [Enemy(*generer_position_ennemi(map, joueur.x, joueur.y)) for _ in range(3)]

    while not game_over and not game_won:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_SPACE:
                    current_time = pygame.time.get_ticks()
                    if current_time - joueur.temps_derniere_bombe > joueur.duree_entre_bombes:
                        x_bombe, y_bombe = joueur.x, joueur.y
                        bombes.append((x_bombe, y_bombe))
                        temps_bombes[(x_bombe, y_bombe)] = current_time
                        joueur.temps_derniere_bombe = current_time

        clock.tick(10)

        for bombe in bombes[:]:
            if pygame.time.get_ticks() - temps_bombes[bombe] > 2000:
                if Bombe.explose(bombe[0], bombe[1], map, marge_x, marge_y, fenetre, joueur, enemies):
                    game_over = True
                bombes.remove(bombe)

        joueur.deplacer(map, bombes)

        fenetre.fill((50, 50, 50))
        afficher_map(map, marge_x, marge_y, fenetre)
        joueur.afficher(fenetre, marge_x, marge_y)
        for bombe in bombes:
            Bombe.afficher(bombe[0], bombe[1], marge_x, marge_y, fenetre)

        for enemy in enemies:
            enemy.draw(marge_x, marge_y, fenetre)
            enemy.update(map, joueur.x, joueur.y, bombes)
            enemy.detecter_collision_enemy_wall(map)

        for enemy in enemies:
            if joueur.x == enemy.x and joueur.y == enemy.y:
                game_over = True

        if not enemies:
            game_won = True

        temps_ecoule = pygame.time.get_ticks() - temps_debut_partie
        afficher_temps(fenetre, temps_ecoule)

        current_time = pygame.time.get_ticks()
        temps_restant_bombe = max(0, joueur.duree_entre_bombes - (current_time - joueur.temps_derniere_bombe))
        afficher_temps_restant_bombe(fenetre, temps_restant_bombe)

        pygame.display.update()

    if game_over:
        game_over_screen(fenetre)
    elif game_won:
        congratulations_screen(fenetre)

if __name__ == "__main__":
    main()
