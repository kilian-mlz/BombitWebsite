import pygame
import sys
import json
import os
from map import charger_map, afficher_map, generer_position_ennemi
from assets import load_assets
from player import Player
from enemy import Enemy
from bomb import Bombe
from constants import *
from game_over import game_over_screen, congratulations_screen

pygame.init()
pygame.mixer.init()

pygame.mixer.music.load('assets/music.mp3')
pygame.mixer.music.play(-1)

explosion_sound = pygame.mixer.Sound('assets/explosion.mp3')

fenetre = pygame.display.set_mode((LARGEUR_FENETRE, HAUTEUR_FENETRE), pygame.FULLSCREEN)
pygame.display.set_caption("Map Bomberman")

TEMPS_POSITION = ((LARGEUR_FENETRE - 200) // 2, HAUTEUR_FENETRE - 40)
TEMPS_RESTANT_BOMBE_POSITION = ((LARGEUR_FENETRE - 300) // 2, HAUTEUR_FENETRE - 80)

def afficher_temps(fenetre, temps_ecoule):
    font = pygame.font.SysFont(None, 36)
    minutes = temps_ecoule // 60000
    seconds = (temps_ecoule % 60000) // 1000
    time_text = f'Temps: {minutes:02}:{seconds:02}'
    timer_surface = font.render(time_text, True, (255, 255, 255))
    fenetre.blit(timer_surface, TEMPS_POSITION)

def afficher_temps_restant_bombe(fenetre, temps_restant):
    font = pygame.font.SysFont(None, 36)
    time_text = f'Temps avant bombe: {temps_restant // 1000}s'
    timer_surface = font.render(time_text, True, (255, 255, 255))
    fenetre.blit(timer_surface, TEMPS_RESTANT_BOMBE_POSITION)

def save_score(player_name, time, num_enemies, speed_level, status):
    score_entry = {
        "name": player_name,
        "time": time // 1000,
        "enemies": num_enemies,
        "speed": speed_level,
        "status": status
    }
    try:
        with open("scores.json", "r") as file:
            try:
                scores = json.load(file)
            except json.JSONDecodeError:
                print("Le fichier scores.json est vide ou corrompu. Réinitialisation du fichier.")
                scores = []
    except FileNotFoundError:
        scores = []

    scores.append(score_entry)
    scores.sort(key=lambda x: x["time"])

    try:
        with open("scores.json", "w") as file:
            json.dump(scores, file, indent=4)
    except Exception as e:
        print(f"Erreur lors de la sauvegarde des scores : {e}")


def main():
    clock = pygame.time.Clock()

    if len(sys.argv) == 4:
        num_enemies = int(sys.argv[1])
        speed_level = sys.argv[2]
        player_name = sys.argv[3]
    else:
        num_enemies = 3
        speed_level = "Normal"
        player_name = "Anonymous"

    speed_map = {
        "Lent": 400,
        "Normal": 200,
        "Rapide": 100
    }

    enemy_speed = speed_map.get(speed_level, 200)

    map = charger_map()
    joueur = Player(1 * TAILLE_CELLULE, 1 * TAILLE_CELLULE)
    game_over = False
    game_won = False

    bombes = []
    temps_bombes = {}
    temps_debut_partie = pygame.time.get_ticks()

    largeur_carte = len(map[0]) * TAILLE_CELLULE
    hauteur_carte = len(map) * TAILLE_CELLULE
    marge_x = (LARGEUR_FENETRE - largeur_carte) // 2
    marge_y = (HAUTEUR_FENETRE - hauteur_carte) // 2

    enemies = [Enemy(*generer_position_ennemi(map, joueur.x, joueur.y)) for _ in range(num_enemies)]
    for enemy in enemies:
        enemy.move_interval = enemy_speed

    while not game_over and not game_won:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_SPACE:
                    current_time = pygame.time.get_ticks()
                    if current_time - joueur.temps_derniere_bombe > joueur.duree_entre_bombes:
                        x_bombe, y_bombe = joueur.x, joueur.y
                        bombes.append((x_bombe, y_bombe))
                        temps_bombes[(x_bombe, y_bombe)] = current_time
                        joueur.temps_derniere_bombe = current_time

        clock.tick(10)

        for bombe in bombes[:]:
            if pygame.time.get_ticks() - temps_bombes[bombe] > 2000:
                if Bombe.explose(bombe[0], bombe[1], map, marge_x, marge_y, fenetre, joueur, enemies):
                    game_over = True
                bombes.remove(bombe)

        joueur.deplacer(map, bombes)

        fenetre.fill((50, 50, 50))
        afficher_map(map, marge_x, marge_y, fenetre)
        joueur.afficher(fenetre, marge_x, marge_y)
        for bombe in bombes:
            Bombe.afficher(bombe[0], bombe[1], marge_x, marge_y, fenetre)

        for enemy in enemies:
            enemy.draw(marge_x, marge_y, fenetre)
            enemy.update(map, joueur.x, joueur.y, bombes)
            enemy.detecter_collision_enemy_wall(map)

        for enemy in enemies:
            if joueur.x == enemy.x and joueur.y == enemy.y:
                game_over = True

        if not enemies:
            game_won = True

        temps_ecoule = pygame.time.get_ticks() - temps_debut_partie
        afficher_temps(fenetre, temps_ecoule)

        current_time = pygame.time.get_ticks()
        temps_restant_bombe = max(0, joueur.duree_entre_bombes - (current_time - joueur.temps_derniere_bombe))
        afficher_temps_restant_bombe(fenetre, temps_restant_bombe)

        pygame.display.update()

    if game_over:
        game_status = "Perdu"
    elif game_won:
        game_status = "Gagner"

    temps_ecoule = pygame.time.get_ticks() - temps_debut_partie
    save_score(player_name, temps_ecoule, num_enemies, speed_level, game_status)

    pygame.mixer.music.stop()

    if game_over:
        game_over_screen(fenetre)
    elif game_won:
        congratulations_screen(fenetre)

if __name__ == "__main__":
    main()
