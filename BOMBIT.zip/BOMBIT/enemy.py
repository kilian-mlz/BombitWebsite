import random
import pygame
from constants import TAILLE_CELLULE
from assets import load_assets

images = load_assets()

class Enemy:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.direction = random.choice(["up", "down", "left", "right"])
        self.speed = TAILLE_CELLULE
        self.last_move_time = pygame.time.get_ticks()
        self.move_interval = 200

    def update(self, map, joueur_x, joueur_y, bombes):
        current_time = pygame.time.get_ticks()
        if current_time - self.last_move_time >= self.move_interval:
            self.last_move_time = current_time
            if random.random() < 0.2:
                self.direction = random.choice(["up", "down", "left", "right"])

            next_x, next_y = self.x, self.y
            if self.direction == "up":
                next_y -= self.speed
            elif self.direction == "down":
                next_y += self.speed
            elif self.direction == "left":
                next_x -= self.speed
            elif self.direction == "right":
                next_x += self.speed

            case_x = next_x // TAILLE_CELLULE
            case_y = next_y // TAILLE_CELLULE

            if (0 <= case_x < len(map[0]) and 0 <= case_y < len(map) and
                map[case_y][case_x] not in [1, 2] and
                not self.detecter_collision_bombes(next_x, next_y, bombes) and
                (next_x != joueur_x or next_y != joueur_y)):
                self.x, self.y = next_x, next_y

    def detecter_collision_bombes(self, x, y, bombes):
        for bombe in bombes:
            if bombe[0] == x and bombe[1] == y:
                return True
        return False

    def draw(self, marge_x, marge_y, fenetre):
        fenetre.blit(images['enemy_up'], (self.x + marge_x, self.y + marge_y))

    def detecter_collision_enemy_wall(self, map):
        case_x = self.x // TAILLE_CELLULE
        case_y = self.y // TAILLE_CELLULE

        if map[case_y][case_x] == 1:
            self.direction = random.choice(["up", "down", "left", "right"])
