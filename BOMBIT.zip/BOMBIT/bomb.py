from constants import TAILLE_CELLULE
from assets import load_assets
import pygame

images = load_assets()

explosion_sound = pygame.mixer.Sound('assets/explosion.mp3')

class Bombe:
    def afficher(x, y, marge_x, marge_y, fenetre):
        x += marge_x
        y += marge_y
        fenetre.blit(images['bomb'], (x, y))

    def explose(x, y, map, marge_x, marge_y, fenetre, joueur, enemies):
        directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]
        explosion_positions = [(x, y)]

        explosion_sound.play()

        for dx, dy in directions:
            for step in range(1, 3):
                next_x = x + dx * step * TAILLE_CELLULE
                next_y = y + dy * step * TAILLE_CELLULE
                case_x = next_x // TAILLE_CELLULE
                case_y = next_y // TAILLE_CELLULE

                if case_x < 0 or case_y < 0 or case_x >= len(map[0]) or case_y >= len(map):
                    break

                if map[case_y][case_x] == 1:
                    break
                elif map[case_y][case_x] == 2: 
                    map[case_y][case_x] = 0
                    explosion_positions.append((next_x, next_y))
                    break
                else:
                    explosion_positions.append((next_x, next_y))

        if (x, y) == (joueur.x, joueur.y):
            return True

        for pos in explosion_positions:
            if (pos[0], pos[1]) == (joueur.x, joueur.y):
                return True
            for enemy in enemies[:]:
                if (pos[0], pos[1]) == (enemy.x, enemy.y):
                    enemies.remove(enemy)

        return False
