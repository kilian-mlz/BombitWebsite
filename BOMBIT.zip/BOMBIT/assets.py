import pygame

def load_assets():
    images = {
        'wall': pygame.image.load('assets/map/wall.png'),
        'grass': pygame.image.load('assets/map/grass.png'),
        'breakable': pygame.image.load('assets/map/breakable.png'),
        'player_down': pygame.image.load('assets/player/player_down.png'),
        'player_up': pygame.image.load('assets/player/player_up.png'),
        'player_left': pygame.image.load('assets/player/player_left.png'),
        'player_right': pygame.image.load('assets/player/player_right.png'),
        'bomb': pygame.image.load('assets/bomb/bomb.png'),
        'explosion': pygame.image.load('assets/bomb/explosion.png'),
        'enemy_up': pygame.image.load('assets/enemy/e_1_up.png')
    }
    return images
