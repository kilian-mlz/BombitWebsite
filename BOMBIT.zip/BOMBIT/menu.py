from tkinter import *
from PIL import ImageTk, Image
import os
import json

def commencer_partie():
    global num_enemies, speed_level, player_name
    if player_name.get().strip() == "":
        player_name.set("Anonymous")
    ecran.destroy()
    os.system(f"python main.py {num_enemies.get()} {speed_level.get()} {player_name.get()}")

def afficher_scores():
    scores_fenetre = Toplevel(ecran)
    scores_fenetre.title("Meilleurs Scores")
    scores_fenetre.geometry("500x500")
    try:
        with open("scores.json", "r") as file:
            scores = json.load(file)
    except FileNotFoundError:
        scores = []
    scores_text = "\n".join(
        [f"{entry.get('name', 'Unknown')} - {entry.get('time', 'N/A')} secondes - Ennemies : {entry.get('enemies', 'N/A')} - Vitesse : {entry.get('speed', 'N/A')} - {entry.get('status', 'N/A')}" for entry in scores]
    )
    scores_label = Label(scores_fenetre, text=scores_text, font=("Helvetica", 12), justify=LEFT)
    scores_label.pack(pady=20, padx=20)

ecran = Tk()
ecran.attributes('-fullscreen', True)

img_fond = ImageTk.PhotoImage(Image.open("assets/background.webp"))
fond = Canvas(ecran, width=400, height=400)
fond.pack(fill="both", expand=True)
fond.create_image(0, 0, image=img_fond, anchor="nw")
fond.config(bg='black')

accueil = Label(fond, text='Bienvenue sur BOMBIT MAN', font=("Helvetica", 24, "bold"), bg='black', fg='white')
accueil.pack(pady=20)

player_frame = Frame(fond, bg='black')
player_frame.pack(pady=10)
player_name_label = Label(player_frame, text="Nom du joueur:", font=("Helvetica", 14), bg='black', fg='white')
player_name_label.pack(side=LEFT, padx=10)
player_name = StringVar(ecran)
player_name_entry = Entry(player_frame, textvariable=player_name, font=("Helvetica", 14))
player_name_entry.pack(side=LEFT, padx=10)

enemies_frame = Frame(fond, bg='black')
enemies_frame.pack(pady=10)
num_enemies_label = Label(enemies_frame, text="Nombre d'ennemis:", font=("Helvetica", 14), bg='black', fg='white')
num_enemies_label.pack(side=LEFT, padx=10)
num_enemies = StringVar(ecran)
num_enemies.set("3")
num_enemies_menu = OptionMenu(enemies_frame, num_enemies, "1", "2", "3", "4", "5")
num_enemies_menu.config(font=("Helvetica", 12))
num_enemies_menu.pack(side=LEFT, padx=10)

speed_frame = Frame(fond, bg='black')
speed_frame.pack(pady=10)
speed_level_label = Label(speed_frame, text="Vitesse des ennemis:", font=("Helvetica", 14), bg='black', fg='white')
speed_level_label.pack(side=LEFT, padx=10)
speed_level = StringVar(ecran)
speed_level.set("Normal")
speed_level_menu = OptionMenu(speed_frame, speed_level, "Lent", "Normal", "Rapide")
speed_level_menu.config(font=("Helvetica", 12))
speed_level_menu.pack(side=LEFT, padx=10)

button_frame = Frame(fond, bg='black')
button_frame.pack(pady=30)
btn1 = Button(button_frame, text='Commencer la partie', command=commencer_partie, font=("Helvetica", 14), width=20)
btn1.pack(pady=10)
btn2 = Button(button_frame, text='Afficher les scores', command=afficher_scores, font=("Helvetica", 14), width=20)
btn2.pack(pady=10)
btn3 = Button(button_frame, text='Quitter le jeu', command=ecran.quit, font=("Helvetica", 14), width=20)
btn3.pack(pady=10)

ecran.mainloop()
