from tkinter import *
from PIL import ImageTk, Image
import os
import tkinter.font as tkFont

ecran = Tk()
ecran.attributes('-fullscreen', True)

press_start_font = tkFont.Font(family="Press Start 2P", size=20)

img_fond = ImageTk.PhotoImage(Image.open("assets/background.webp"))
fond = Canvas(ecran, width=400, height=400)
fond.pack(fill="both", expand=True)
fond.create_image(0, 0, image=img_fond, anchor="nw")
fond.config(bg='black')

# Utiliser la police "Press Start 2P" pour le texte
accueil = Label(fond, text='Bienvenue sur BOMBIT MAN', font=press_start_font)
accueil.pack()

btn1 = Button(fond, text='Commencer la partie', font=press_start_font)
btn1.config(width=15, height=2)
btn1.pack(pady=50)
btn2 = Button(fond, text='Quitter le jeu', font=press_start_font, command=ecran.quit)
btn2.config(width=15, height=2)
btn2.pack()

ecran.mainloop()
