import random
from assets import load_assets
from constants import TAILLE_CELLULE

images = load_assets()
largeur = 21
hauteur = 21

def charger_map():
    carte = [[0 for _ in range(largeur)] for _ in range(hauteur)]

    for i in range(hauteur):
        for j in range(largeur):
            if i == 0 or j == 0 or i == hauteur - 1 or j == largeur - 1:
                carte[i][j] = 1

    for i in range(2, hauteur - 1, 2):
        for j in range(2, largeur - 1, 2):
            carte[i][j] = 1

    for i in range(1, hauteur - 1):
        for j in range(1, largeur - 1):
            if carte[i][j] == 0 and random.random() < 0.30:
                if not (abs(i - 1) <= 3 and abs(j - 1) <= 3):
                    carte[i][j] = 2

    return carte

def afficher_map(map, marge_x, marge_y, fenetre):
    from assets import load_assets
    images = load_assets()
    for i in range(len(map)):
        for j in range(len(map[i])):
            x = j * TAILLE_CELLULE + marge_x
            y = i * TAILLE_CELLULE + marge_y
            if map[i][j] == 1:
                fenetre.blit(images['wall'], (x, y))
            elif map[i][j] == 2:
                fenetre.blit(images['breakable'], (x, y))
            else:
                fenetre.blit(images['grass'], (x, y))

def generer_position_ennemi(map, joueur_x, joueur_y):
    while True:
        x = random.randint(0, len(map[0]) - 1) * TAILLE_CELLULE
        y = random.randint(0, len(map) - 1) * TAILLE_CELLULE
        case_x = x // TAILLE_CELLULE
        case_y = y // TAILLE_CELLULE
        if (map[case_y][case_x] == 0 and
            abs(x - joueur_x) > 3 * TAILLE_CELLULE and
            abs(y - joueur_y) > 3 * TAILLE_CELLULE):
            return x, y
