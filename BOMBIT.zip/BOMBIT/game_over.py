import pygame
import sys
from constants import LARGEUR_FENETRE, HAUTEUR_FENETRE

def game_over_screen(fenetre):
    font_large = pygame.font.SysFont(None, 100)
    font_small = pygame.font.SysFont(None, 50)

    game_over_text = font_large.render("GAME OVER", True, (0, 0, 0))
    retry_text = font_small.render("Press R to Restart", True, (0, 0, 0))
    quit_text = font_small.render("Press ESC to Quit", True, (0, 0, 0))

    game_over_text_rect = game_over_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2))
    retry_text_rect = retry_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2 + 100))
    quit_text_rect = quit_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2 + 200))

    fenetre.blit(game_over_text, game_over_text_rect)
    fenetre.blit(retry_text, retry_text_rect)
    fenetre.blit(quit_text, quit_text_rect)

    pygame.display.update()

    waiting_for_input = True
    while waiting_for_input:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    waiting_for_input = False
                    from main import main
                    main()
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

def congratulations_screen(fenetre):
    font_large = pygame.font.SysFont(None, 100)
    font_small = pygame.font.SysFont(None, 50)

    congratulations_text = font_large.render("CONGRATULATIONS", True, (0, 0, 0))
    retry_text = font_small.render("Press R to Restart", True, (0, 0, 0))
    quit_text = font_small.render("Press ESC to Quit", True, (0, 0, 0))

    congratulations_text_rect = congratulations_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2))
    retry_text_rect = retry_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2 + 100))
    quit_text_rect = quit_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2 + 200))

    fenetre.blit(congratulations_text, congratulations_text_rect)
    fenetre.blit(retry_text, retry_text_rect)
    fenetre.blit(quit_text, quit_text_rect)

    pygame.display.update()

    waiting_for_input = True
    while waiting_for_input:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    waiting_for_input = False
                    from main import main
                    main()
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
