import pygame
import sys
import os
from constants import LARGEUR_FENETRE, HAUTEUR_FENETRE

def game_over_screen(fenetre):
    font_large = pygame.font.SysFont(None, 100)
    font_small = pygame.font.SysFont(None, 50)

    game_over_text = font_large.render("PERDU !", True, (0, 0, 0))
    retry_text = font_small.render("Appuyez sur R pour recommencer", True, (0, 0, 0))
    menu_text = font_small.render("Appuyez sur M pour retourner au menu", True, (0, 0, 0))

    game_over_text_rect = game_over_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2))
    retry_text_rect = retry_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2 + 100))
    menu_text_rect = menu_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2 + 200))

    fenetre.blit(game_over_text, game_over_text_rect)
    fenetre.blit(retry_text, retry_text_rect)
    fenetre.blit(menu_text, menu_text_rect)

    pygame.display.update()

    waiting_for_input = True
    while waiting_for_input:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    waiting_for_input = False
                    from main import main
                    main()
                elif event.key == pygame.K_m:
                    waiting_for_input = False
                    os.system("python menu.py")

def congratulations_screen(fenetre):
    font_large = pygame.font.SysFont(None, 100)
    font_small = pygame.font.SysFont(None, 50)

    congratulations_text = font_large.render("BRAVO !", True, (0, 0, 0))
    retry_text = font_small.render("Appuyez sur R pour recommencer", True, (0, 0, 0))
    menu_text = font_small.render("Appuyez sur M pour retourner au menu", True, (0, 0, 0))

    congratulations_text_rect = congratulations_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2))
    retry_text_rect = retry_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2 + 100))
    menu_text_rect = menu_text.get_rect(center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE // 2 + 200))

    fenetre.blit(congratulations_text, congratulations_text_rect)
    fenetre.blit(retry_text, retry_text_rect)
    fenetre.blit(menu_text, menu_text_rect)

    pygame.display.update()

    waiting_for_input = True
    while waiting_for_input:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    waiting_for_input = False
                    from main import main
                    main()
                elif event.key == pygame.K_m:
                    waiting_for_input = False
                    os.system("python menu.py")
