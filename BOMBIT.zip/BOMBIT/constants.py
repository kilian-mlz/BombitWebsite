import pygame

pygame.init()
info = pygame.display.Info()

LARGEUR_FENETRE = info.current_w
HAUTEUR_FENETRE = info.current_h
TAILLE_CELLULE = 40
DUREE_ENTRE_BOMBES = 4000
